package com.example.android.animequiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the SCORE button is clicked to count the score
     */
    public void score(View view) {
        CharSequence text;
        int scoreCount = 0;
        CheckBox checkbox1_3 = findViewById(R.id.checkbox1_3);
        if (!checkbox1_3.isChecked()) {
            CheckBox checkbox1_1 = findViewById(R.id.checkbox1_1);
            if (checkbox1_1.isChecked()) {
                scoreCount++;
            }
            CheckBox checkbox1_2 = findViewById(R.id.checkbox1_2);
            if (checkbox1_2.isChecked()) {
                scoreCount++;
            }
        }
        RadioButton radio1 = findViewById(R.id.radio1_1);
        if (radio1.isChecked()) {
            scoreCount++;
        }
        RadioButton radio2 = findViewById(R.id.radio2_1);
        if (radio2.isChecked()) {
            scoreCount++;
        }
        RadioButton radio3 = findViewById(R.id.radio3_1);
        if (radio3.isChecked()) {
            scoreCount++;
        }
        RadioButton radio4 = findViewById(R.id.radio4_3);
        if (radio4.isChecked()) {
            scoreCount++;
        }
        EditText editText1 = findViewById(R.id.editText1);
        String userEntry = editText1.getText().toString();
        if (userEntry.equals(getString(R.string.answer6))){
            scoreCount++;
        }
        if (scoreCount <= 3 && scoreCount > 0) {
            text = getString(R.string.goodScore) + scoreCount + getString(R.string.amountOfAnswers);
        } else if (scoreCount <= 6 && scoreCount > 3) {
            text = getString(R.string.greatScore) + scoreCount + getString(R.string.amountOfAnswers);
        } else if (scoreCount == 7) {
            text = getString(R.string.perfectScore);
        } else {
            text = getString(R.string.noScore);
        }

        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }
}
